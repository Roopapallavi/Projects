package com.walletapp;

import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.walletapp.App;
import com.walletapp.bean.CustomerDetails;
import com.walletapp.exception.WalletException;
import com.walletapp.service.IWalletService;
import com.walletapp.service.WalletService;

/**
 * Hello world!
 *
 */
public class App 
{
	IWalletService walletService=new WalletService();
  	Scanner scan=new Scanner(System.in);
  	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		App a=new App();
		a.scan.useDelimiter("\n");
		String option=null;
		while(true) {
		System.out.println("======Wallet Application=======");
		System.out.println("1.Create New Account");
		System.out.println("2.Show Balance Amount");
		System.out.println("3.Deposit Amount");
		System.out.println("4.Withdraw Money");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		System.out.println("Enter your choice");
		option=a.scan.nextLine();
		switch(option) {
		case "1":
			a.createAccount();
			break;
		case "2":
			a.showBalance();
			break;
		case "3":
			a.deposit();
			break;
		case "4":
			a.withdraw();
			break;
		case "5":
			a.fundTransfer();
			break;
		case "6":
			a.printTransactions();
			break;
		case "7":
			System.exit(0);
			break;
		default:
				System.out.println("Enter a valid choice within 1 and 7");
				break;
		}
		}
	}
	private void createAccount() {
		CustomerDetails cd=new CustomerDetails();
		System.out.println("Enter customer name");
		cd.setCustomerName(scan.nextLine());
		System.out.println("Enter mobile number");
		cd.setMoblieNumber(scan.nextLine());
		System.out.println("Enter gender");
		cd.setGender(scan.nextLine());
		System.out.println("Enter age");
		cd.setAge(scan.nextLine());
		System.out.println("Enter address");
		cd.setAddress(scan.nextLine());
		System.out.println("Enter account type");
		cd.setAccountType(scan.nextLine());
		System.out.println("Enter depositing amount");
		cd.setBalance(Double.parseDouble(scan.nextLine()));
		
		try {
			boolean result=walletService.validateEmployee(cd);
		if(result) {
			System.out.println("Account created successfully...");
			System.out.println("Set pin number");
			cd.setAtmPin(scan.nextLine());
			boolean pin=walletService.validatePin(cd.getAtmPin());
			if(pin) {
				System.out.println("pin set successfully");
				Long accno =walletService.addCustomer(cd);
				System.out.println("Account Number is: " +accno);
			}
				
		}
			}
			catch (WalletException e) {
				System.err.println("An error occured "+e.getMessage());
			}

	}
	private void showBalance()  {
		System.out.println("Enter account number");
		String ac=scan.nextLine();
		System.out.println("Enter 4 digits pin");
		String pin=scan.nextLine();
		try {
		Long accnum=Long.parseLong(ac);
         CustomerDetails cd=walletService.getBalance(accnum,pin);
		if(cd!=null) {
         System.out.println(cd);
		}
		
		}
		catch(WalletException e){
			System.err.println("An error occured "+e.getMessage());
		}
	}
	private void deposit() {
		System.out.println("Enter account number: ");
		String ac=scan.nextLine();
		System.out.println("Enter 4 digits pin: ");
		String pin=scan.nextLine();
		System.out.println("Enter deposit amount: ");
		String amt=scan.nextLine();
		try {
			Long accnum=Long.parseLong(ac);
			 CustomerDetails cd=walletService.setDeposit(accnum,pin,amt);
			 if(cd!=null) {
				 System.out.println("Deposited successfully");
				 System.out.println(cd);
		}
		}
		catch(Exception e){
			System.err.println("An error occured "+e.getMessage());
		}
	}
	private void withdraw() {
		System.out.println("Enter account number: ");
		String ac=scan.nextLine();
		System.out.println("enter 4 digits pin: ");
		String pin=scan.nextLine();
		System.out.println("Enter withdraw amount: ");
		String amt=scan.nextLine();
		try {
			Long accnum=Long.parseLong(ac);
			 CustomerDetails cd=walletService.getWithdraw(accnum,pin,amt);
			if(cd!=null) {	
			 System.out.println(cd);
		}
			}
		catch(Exception e){
			System.err.println("An error occured "+e.getMessage());
		}
		
	}
	private void fundTransfer() {
		System.out.println("Enter Reciever account number to transfer the amount: ");
		String oac=scan.nextLine();
		System.out.println("Enter your account number: ");
		String ac=scan.nextLine();
		System.out.println("Enter 4 digits pin: ");
		String pin=scan.nextLine();
		System.out.println("Enter amount: ");
		String amt=scan.nextLine();
		try {
			Long accnum=Long.parseLong(ac);
			Long oaccnum=Long.parseLong(oac);
			 CustomerDetails cd=walletService.getFundTransfer(accnum,oaccnum,pin,amt);
				if(cd!=null) {
					System.out.println("Fund transfered successfully");
			 System.out.println(cd);
		}
		}
		catch(Exception e){
			System.err.println("An error occured "+e.getMessage());
		}
		
	}
	private void printTransactions() {
		System.out.println("Enter account number: ");
		String ac=scan.nextLine();
		System.out.println("Enter 4 digits pin: ");
		String pin=scan.nextLine();
		try {
			Long accnum=Long.parseLong(ac);
			boolean b=walletService.getPrintTransactions(accnum,pin);
			if(b) {
				System.err.println("print transactions failed");
			}
								}
		
		catch(Exception e){
			System.err.println("An error occured "+e.getMessage());
		}
		   }
}
