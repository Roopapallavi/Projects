package com.walletapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.walletapp.bean.CustomerDetails;
import com.walletapp.bean.TransactionDetails;
import com.walletapp.exception.WalletException;
import com.walletapp.util.DBConnection;

public class WalletDao implements IWalletDao {
	 Logger logger=Logger.getRootLogger();
	 int id=0;
	 public WalletDao() {
			
			PropertyConfigurator.configure("resources//log4j.properties");
		}
	
	@Override
	public Long addCustomer(CustomerDetails cd) throws WalletException {

Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		Long accNo=0l;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QuerryMapper.INSERT_QUERY);

			preparedStatement.setString(1,cd.getAge());
			preparedStatement.setString(2,cd.getCustomerName());
			preparedStatement.setDouble(3,cd.getBalance());
			preparedStatement.setString(4,cd.getAddress());
			preparedStatement.setString(5,cd.getMoblieNumber());
			preparedStatement.setString(6,cd.getAccountType());
			preparedStatement.setString(7,cd.getGender());
			preparedStatement.setString(8,cd.getAtmPin());
					
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QuerryMapper.ACCOUNTNUMBER_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				accNo=resultSet.getLong(1);
						
			}
	
			if(queryResult==0)
			{
				
				throw new WalletException("Inserting customer details failed ");

			}
			else
			{
				System.out.println("customer details added successfully:");
				return (long) accNo;
			}
		 }
		catch(SQLException sqlException)
		{
						sqlException.printStackTrace();
						throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}
	@Override
	public CustomerDetails getBalance(Long accnum,String pin) throws WalletException {
		CustomerDetails cd=new CustomerDetails();
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QuerryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, accnum);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				
					if(!pin.equalsIgnoreCase(resultSet.getString("atmpin"))) {
						System.err.println("Enter the correct pin.Invalid User");
						}	
					else {
						double balance=resultSet.getDouble("balance");
						cd.setBalance(balance);
						cd.setAccountNumber(accnum);
						cd.setCustomerName(resultSet.getString("customername"));
						//System.out.println(balance);
						return cd;
						
					}
				}
				else {
					System.err.println("customer with the account number "+accnum+" Not existed");
				}
				}
	catch(SQLException sqlException)
	{
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletException("Error in closing db connection");	
		}
	}
		return null;
		
			
	}
	@Override
	public CustomerDetails setDeposit(Long accnum, String pin, String amt) throws WalletException {
		CustomerDetails cd=new CustomerDetails();
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement transStatement=null;
		PreparedStatement preparedStatement=null;	
		PreparedStatement preparedStatement1=null;	
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		
		int queryResult=0;
		try {
			

			preparedStatement=connection.prepareStatement(QuerryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, accnum);			
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
					if(pin.equalsIgnoreCase(resultSet.getString("atmpin"))) {
						
						double balance=resultSet.getDouble("balance");
						double newbal=balance + Double.parseDouble(amt);
						preparedStatement1=connection.prepareStatement(QuerryMapper.UPDATE_QUERY);
						preparedStatement1.setDouble(1, newbal);
						preparedStatement1.setLong(2, accnum);
					
						resultSet1=preparedStatement1.executeQuery();
						cd.setBalance(newbal);
						cd.setAccountNumber(accnum);
						cd.setCustomerName(resultSet.getString("customername"));
						transStatement=connection.prepareStatement(QuerryMapper.TRANSINSERT_QUERY);
						transStatement.setLong(1, accnum);
						transStatement.setString(2, "Deposite");
						transStatement.setDouble(3, Double.parseDouble(amt));
					PreparedStatement date1=connection.prepareStatement("select sysdate from dual");
						ResultSet r1=date1.executeQuery();
						if(r1.next()) {
							
						Date d=r1.getDate(1);
						transStatement.setDate(4, d);
						}
						
						queryResult=transStatement.executeUpdate();
						transStatement = connection.prepareStatement(QuerryMapper.TRANSID_QUERY_SEQUENCE);
						ResultSet result = transStatement.executeQuery();
						if(result.next())
						{
							int transid = resultSet.getInt(1);
									
						}
						return cd;
				}	
					else {
						
						System.err.println("Enter the correct pin.Invalid User");
						
					}
				}
				else {
					System.err.println("customer with the account number "+accnum+" Not existed");
				}
			
		
				}
	catch(SQLException sqlException)
	{
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletException("Error in closing db connection");	
		}
	}
		return null;
		
			
	}
	@Override
	public CustomerDetails getWithdraw(Long accnum, String pin, String amt) throws WalletException {
		CustomerDetails cd=new CustomerDetails();
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;	
		PreparedStatement preparedStatement1=null;	
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		
		try {
			preparedStatement=connection.prepareStatement(QuerryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, accnum);			
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
					if(pin.equalsIgnoreCase(resultSet.getString("atmpin"))) {
						
						double balance=resultSet.getDouble("balance");
						if(balance < Double.parseDouble(amt)) {
							throw new WalletException("Insufficient balance");
						}
						else {
						double newbal=balance - Double.parseDouble(amt);
						preparedStatement1=connection.prepareStatement(QuerryMapper.UPDATE_QUERY);
						preparedStatement1.setDouble(1, newbal);
						preparedStatement1.setLong(2, accnum);
						
						
						resultSet1=preparedStatement1.executeQuery();
						cd.setBalance(newbal);
						cd.setAccountNumber(accnum);
						cd.setCustomerName(resultSet.getString("customername"));
						
						PreparedStatement transStatement = connection.prepareStatement(QuerryMapper.TRANSINSERT_QUERY);
						transStatement.setLong(1, accnum);
						transStatement.setString(2, "Withdraw");
						transStatement.setDouble(3, Double.parseDouble(amt));
					PreparedStatement date1=connection.prepareStatement("select sysdate from dual");
						ResultSet r1=date1.executeQuery();
						if(r1.next()) {
							
						Date d=r1.getDate(1);
						transStatement.setDate(4, d);
						}
						
						int queryResult = transStatement.executeUpdate();
						transStatement = connection.prepareStatement(QuerryMapper.TRANSID_QUERY_SEQUENCE);
						ResultSet result = transStatement.executeQuery();
						if(result.next())
						{
							int transid = resultSet.getInt(1);
									
						}
						return cd;
						}
				}	
					else {
						
						System.err.println("Enter the correct pin.Invalid User");
						
					}
				}
				else {
					System.err.println("customer with the account number "+accnum+" Not existed");
				}
			
		
				}
	catch(SQLException sqlException)
	{
		
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			preparedStatement1.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletException("Error in closing db connection");	
		}
	}
		return null;
		
			
				
	}
	@Override
	public CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt) throws WalletException {
		
		CustomerDetails cd=new CustomerDetails();
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement spreparedStatement=null;	
		PreparedStatement spreparedStatement1=null;	
		PreparedStatement upreparedStatement=null;	
		PreparedStatement upreparedStatement1=null;	
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		ResultSet oresultSet = null;
		ResultSet oresultSet1 = null;
		
		try {
			spreparedStatement=connection.prepareStatement(QuerryMapper.SELECT_QUERY);
			spreparedStatement.setLong(1, accnum);			
			resultSet=spreparedStatement.executeQuery();
//			System.out.println("hii");
			spreparedStatement1=connection.prepareStatement(QuerryMapper.SELECT_QUERY);
			spreparedStatement1.setLong(1, oaccnum);			
			oresultSet=spreparedStatement1.executeQuery();
			
			if(resultSet.next() )
			{
				
					if(pin.equalsIgnoreCase(resultSet.getString("atmpin"))) {
						
						double balance=resultSet.getDouble("balance");
						if(balance < Double.parseDouble(amt)) {
							throw new WalletException("Insufficient balance");
						}
						else {
						
						double newbal=balance - Double.parseDouble(amt);
						upreparedStatement=connection.prepareStatement(QuerryMapper.UPDATE_QUERY);
						upreparedStatement.setDouble(1, newbal);
						upreparedStatement.setLong(2, accnum);
						resultSet1=upreparedStatement.executeQuery();
								
						if(oresultSet.next())
						{
						double balance1=oresultSet.getDouble("balance");
						double othbal=balance1 + Double.parseDouble(amt);
						upreparedStatement1=connection.prepareStatement(QuerryMapper.UPDATE_QUERY);
						upreparedStatement1.setDouble(1,othbal);
						upreparedStatement1.setLong(2,oaccnum);
					                                    
						oresultSet1=upreparedStatement1.executeQuery();
						}				
						
						else{
							System.err.println("customer with the account number "+oaccnum+" Not existed");
						}
						cd.setBalance(newbal);
						cd.setAccountNumber(accnum);
						cd.setCustomerName(resultSet.getString("customername"));
						
						PreparedStatement transStatement = connection.prepareStatement(QuerryMapper.TRANSINSERT_QUERY);
						transStatement.setLong(1, accnum);
						transStatement.setString(2, "Fund Transfer");
						transStatement.setDouble(3, Double.parseDouble(amt));
					PreparedStatement date1=connection.prepareStatement("select sysdate from dual");
						ResultSet r1=date1.executeQuery();
						if(r1.next()) {
							
						Date d=r1.getDate(1);
						transStatement.setDate(4, d);
						}
						
						int queryResult = transStatement.executeUpdate();
						transStatement = connection.prepareStatement(QuerryMapper.TRANSID_QUERY_SEQUENCE);
						ResultSet result = transStatement.executeQuery();
						if(result.next())
						{
							int transid = resultSet.getInt(1);
									
						}
						return cd;
						}
									}
			
					
					else {
						
						System.err.println("Enter the correct pin.Invalid User");
						
					}
			}
				else {
					System.err.println("customer with the account number "+accnum+" Not existed");
				}
			
		
				}
	catch(SQLException sqlException)
	{
		
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			spreparedStatement.close();
			spreparedStatement1.close();
			upreparedStatement.close();
			upreparedStatement1.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletException("Error in closing db connection");	
		}
	}
		return null;
		
	}
	@Override
	public 	boolean getPrintTransactions(Long accnum, String pin) throws WalletException {
	
		
		TransactionDetails td=new TransactionDetails();
		Connection connection = DBConnection.getInstance().getConnection();	

		PreparedStatement preparedStatement=null;
		PreparedStatement transStatement=null;
		ResultSet resultSet = null;
		ResultSet transresult=null;
		try {
					
			preparedStatement=connection.prepareStatement(QuerryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, accnum);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
                          if(!pin.equalsIgnoreCase(resultSet.getString("atmpin"))) {
						     System.err.println("Enter the correct pin.Invalid User");
						       }	
					         else {
					        	 transStatement=connection.prepareStatement(QuerryMapper.TRANSSELECT_QUERY);
					 			transStatement.setLong(1, accnum);
					 			transresult=transStatement.executeQuery();
					 			while(transresult.next()) {
					 				td.setTransType(transresult.getString("transtype"));
					 				td.setAmount(transresult.getDouble("balance"));
					 				td.setDot(transresult.getDate("transdate"));
					 				System.out.println(td);
					 			}
		                        }
                   }
		else {
			System.err.println("customer with the account number "+accnum+" Not existed");
		}
		}
		catch(SQLException sqlException)
		{
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new WalletException("Error in closing db connection");	
			}
		}
			
			return false;
			
			
}
}

