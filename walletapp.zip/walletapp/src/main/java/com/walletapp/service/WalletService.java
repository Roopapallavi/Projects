package com.walletapp.service;

import com.walletapp.bean.CustomerDetails;
import com.walletapp.dao.IWalletDao;
import com.walletapp.dao.WalletDao;
import com.walletapp.exception.WalletException;

public class WalletService implements IWalletService {
	 IWalletDao walletDao=new WalletDao();
		@Override
	public boolean validateEmployee(CustomerDetails cd) throws WalletException {
			if(validateName(cd.getCustomerName()) && validateMobile(cd.getMoblieNumber()) && validateAddress(cd.getAddress()) && validateGender(cd.getGender()) && validateAge(cd.getAge()) && validateAccountType(cd.getAccountType())) {
				return true;
			}
			return false;
		}
	private boolean validateAccountType(String accountType) throws WalletException {
			if(accountType.isEmpty() || accountType==null) {
				throw new WalletException("Customer account type cannot be empty");
			}
			else if(accountType.equalsIgnoreCase("savings") || accountType.equalsIgnoreCase("current")) {
				return true;
			}
			else {
				throw new WalletException("Customer account type should be either savings or current");
			}
		}
	private boolean validateAge(String age) throws WalletException {
		 if(age.isEmpty() || age==null) {
			  throw new WalletException("Age is mandatory");
		  }
		  else {
			  if(age.matches("[A-Za-z]{1,}"))
			  {
				  throw new WalletException("Enter a valid age");
			  }
			  else if(Integer.parseInt(age)<18 || Integer.parseInt(age)>120) {
				  throw new WalletException("Enter a valid age");
			  }
		  }
		  return true;
		}
	private boolean validateGender(String gender) throws WalletException {
		if(gender.isEmpty() || gender==null) {
			throw new WalletException("Gender cannot be empty");
		}
		else if(gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female") || gender.equalsIgnoreCase("others") ) {
			return true;
		}
		else {
			throw new WalletException("Invalid Gender");
		}
		}
	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty() || name==null) {
			throw new WalletException("Customer Name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")){
				throw new WalletException("Name should start with a capital letter follwed by a minimum of 3 alphabets");
			}
		}
		return true;
	}
	private boolean validateMobile(String mobile)throws WalletException{
		if(mobile.isEmpty() || mobile==null) {
			throw new WalletException("Mobile number is mandatory");
		}
		else {
			if(!mobile.matches("\\d{10}")) //d -> digit
			{ 
				throw new WalletException("Mobile number should contain only 10 digits");
			}
		}
		return true;
	}
		private boolean validateAddress(String address) throws WalletException{
			if(address.isEmpty() || address==null) {
				throw new WalletException("Address cannot be empty");
			}
			
			return true;
			
		}
			
	
	@Override
	public Long addCustomer(CustomerDetails cd) throws WalletException {
		
		return walletDao.addCustomer(cd);
	}
	@Override
	public boolean validatePin(String pin) throws WalletException {
		if(pin.isEmpty() || pin==null) {
			throw new WalletException("Pin number can't be empty");
		}
		else {
			if(!pin.matches("\\d{4}")) //d -> digit
			{ 
				throw new WalletException("Pin number should contain only 4 digits");
			}
		}
		return true;
	}
	@Override
	public CustomerDetails getBalance(Long accnum,String pin) throws WalletException {
		
		return walletDao.getBalance(accnum,pin);
	}
	@Override
	public CustomerDetails setDeposit(Long accnum, String pin, String amt) throws WalletException {
		// TODO Auto-generated method stub
		return walletDao.setDeposit(accnum,pin,amt);
	}
	@Override
	public CustomerDetails getWithdraw(Long accnum, String pin, String amt) throws WalletException {
		// TODO Auto-generated method stub
		return walletDao.getWithdraw(accnum,pin,amt);
	}
	@Override
	public CustomerDetails getFundTransfer(Long accnum, Long oaccnum, String pin, String amt) throws WalletException {
		// TODO Auto-generated method stub
		return walletDao.getFundTransfer(accnum,oaccnum,pin,amt);
	}
	@Override
	public boolean getPrintTransactions(Long accnum, String pin) throws WalletException {
		// TODO Auto-generated method stub
	return walletDao.getPrintTransactions(accnum,pin);
	}
	

	}

