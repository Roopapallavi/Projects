package com.wallet.DB;

import java.util.HashMap;

import com.wallet.bean.Customer;

public class BankDB {
private static HashMap<Integer,Customer> customerMap=new HashMap<Integer,Customer>();
static {
	customerMap.put(1991, new Customer(1991,"Swar","8939628680","swarh@gmail.com","Chennai",300000,1227,null));
	customerMap.put(1992, new Customer(1992,"Roopa","8888888888","roopa@outlook.com","Banglore",150000,4123,null));
	customerMap.put(1993, new Customer(1993,"Sara","7777777777","sara@ymail.com","Chennai",600000,3214,null));
	customerMap.put(1994, new Customer(1994,"Kundan","6666666666","kundan@gmail.com","Hyderbad",450000,1111,null));
	customerMap.put(1995, new Customer(1995,"Murali","9898989898","murali@gmail.com","Delhi",290000,1221,null));
	customerMap.put(1996, new Customer(1996,"Chakri","67676767679","chakri@gmail.com","Pune",330000,3339,null));
}

public static HashMap<Integer,Customer> getCustomerMap(){
	return customerMap;
}
}
