package com.wallet.bean;

public class Customer {
	private int accNumber;
	private String custname;
	private String mobile;
	private String email;
	private String address;
	private double accbalance;
	private int pin;
	private String transaction;
	
	public Customer() {
		
	}
	
	

	
	public Customer(int accNumber, String name, String mobile, String email, String address, double balance,int pin, String transaction) {
		super();
		this.accNumber = accNumber;
		custname = name;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		accbalance = balance;
		this.pin=pin;
		this.transaction=transaction;
	}




	public String getTransaction() {
		return transaction;
	}




	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}




	public int getAccNumber() {
		return accNumber;
	}




	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}




	public String getcustName() {
		return custname;
	}




	public void setcustName(String name) {
		custname = name;
	}




	public String getMobile() {
		return mobile;
	}




	public void setMobile(String mobile) {
		this.mobile = mobile;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public double getBalance() {
		return accbalance;
	}




	public void setBalance(double balance) {
		accbalance = balance;
	}
	
	public int getPin() {
		return pin;
	}




	public void setPin(int pin) {
		this.pin = pin;
	}




	@Override
	public String toString() {
		return "Customer [accNumber=" + accNumber + ", name=" + custname + ", mobile=" + mobile + ", email=" + email + ", address="
				+ address + ", balance="+accbalance+", transaction="+transaction+"]";
	}
	
	
	
}
