package com.wallet.service;
import com.wallet.bean.Customer;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {
WalletDao dao=new WalletDaoImpl();
	@Override
	public Customer showBalance(int accNumber) throws WalletException {
		// TODO Auto-generated method stub
		return dao.showBalance(accNumber);
	}
	@Override
	public int createAccount(Customer cust) throws WalletException {
		// TODO Auto-generated method stub
		return dao.createAccount(cust);
	}
	
	@Override
	public boolean validateCustomer(Customer cust) throws WalletException {
		if (validateName(cust.getcustName()) && validateMobile(cust.getMobile()) && validateEmail(cust.getEmail()) && validateAddr(cust.getAddress()) ) {
			return true;
		}
		return false;
	}

	private boolean validateName(String name) throws WalletException {
		if (name.isEmpty() || name == null) {
			throw new WalletException("Employee Name cannot be empty");
		} else {
			if (!name.matches("[A-Z][A-Za-z ]{2,}")) {
				throw new WalletException(
						"Name should start with a Capital letter containing minimum of 2 alphabets");
			}
		}
		return true;
	}

	private boolean validateMobile(String mobile) throws WalletException {

		if (mobile.isEmpty() || mobile == null) {
			throw new WalletException("Mobile Number is mandatory");

		} else {
			if (!mobile.matches("\\d{10}")) {
				throw new WalletException("Mobile number should contain 10 digits");
			}
		}
		return true;
	}
	
	private boolean validateEmail(String email) throws WalletException {
		if(!email.matches("[A-Za-z0-9_]+@+[a-z]+\\.com")) {
			throw new WalletException("Please enter a valid email Id");
		}
		return true;
	}
	
	private boolean validateAddr(String addr) throws WalletException {
		if(addr.isEmpty()||addr==null) {
			throw new WalletException("Address is mandatory");
		}
		return true;
	}

	@Override
	public boolean deposit(int num, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.deposit(num, amount);
	}
	@Override
	public boolean withdraw(int num, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.withdraw(num,amount);
	}
	@Override
	public boolean fundTransfer(int num, int num1, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return dao.fundTransfer(num, num1, amount);
	}
	@Override
	public String printTransaction(int num) throws WalletException {
		// TODO Auto-generated method stub
		return dao.printTransaction(num);
	}

}
