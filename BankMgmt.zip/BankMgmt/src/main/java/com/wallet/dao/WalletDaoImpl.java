package com.wallet.dao;

import java.util.HashMap;
import java.util.Optional;
import java.util.Scanner;
import com.wallet.DB.BankDB;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	Scanner scan = new Scanner(System.in);
	static HashMap<Integer, Customer> customerMap = BankDB.getCustomerMap();

	@Override
	public Customer showBalance(int accNumber) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Customer customers = customerMap.get(accNumber);

			if (customers == null) {
				throw new WalletException("Employee with Id:" + accNumber + "Not available in the database");
			}
			return customers;
		} catch (Exception ex) {
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public int createAccount(Customer cust) throws WalletException {

		try {
			if (customerMap.size() == 0) {
				cust.setAccNumber(7678);
			} else {
				Optional<Integer> id = customerMap.keySet().stream().max((x, y) -> (x > y) ? 1 : (x < y) ? -1 : 0);
				int reqId = id.get() + 1;
				cust.setAccNumber(reqId);
			}
			customerMap.put(cust.getAccNumber(), cust);
			return cust.getAccNumber();
		} catch (Exception ex) {
			throw new WalletException(ex.getMessage());
		}

	}

	@Override
	public boolean deposit(int num, double amount) throws WalletException {

		try {
			Customer c = customerMap.get(num);

			if (c == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = customerMap.get(num).getBalance();
				amount1 = amount1 + amount;
				c.setBalance(amount1);
				c.setTransaction("Amount " + amount + " credited to account " + num);
				customerMap.replace(c.getAccNumber(), c);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean withdraw(int num, double amount) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Customer c = customerMap.get(num);

			if (c == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = customerMap.get(num).getBalance();
				amount1 = amount1 - amount;
				c.setBalance(amount1);
				c.setTransaction("Amount " + amount + " withdrawn from your account " + num);
				customerMap.replace(c.getAccNumber(), c);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return true;
	}

	@Override
	public boolean fundTransfer(int num, int num1, double amount) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Customer c = customerMap.get(num1);

			if (c == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = customerMap.get(num1).getBalance();
				amount1 = amount1 + amount;
				c.setBalance(amount1);
				c.setTransaction("Amount " + amount + " credited to account " + num);

				customerMap.replace(c.getAccNumber(), c);
			}
			Customer c1 = customerMap.get(num);

			if (c1 == null) {
				throw new WalletException("Invalid id");

			} else {
				double amount1 = customerMap.get(num).getBalance();
				amount1 = amount1 - amount;
				c1.setBalance(amount1);
				c1.setTransaction("Amount " + amount + " withdrawn from your account " + num
						+ " and transfered to account " + num1);
				customerMap.replace(c1.getAccNumber(), c1);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return true;
	}

	@Override
	public String printTransaction(int num) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Customer c1 = customerMap.get(num);

			if (c1 == null) {
				throw new WalletException("Employee with Id:" + num + "Not available in the database");
			}
			return c1.getTransaction();
		} catch (WalletException ex) {
			throw new WalletException(ex.getMessage());
		}
	}
}
