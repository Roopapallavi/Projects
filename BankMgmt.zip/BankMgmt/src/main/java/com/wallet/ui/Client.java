package com.wallet.ui;

import java.util.HashMap;
import java.util.Scanner;
import com.wallet.DB.BankDB;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

public class Client {
	static HashMap<Integer, Customer> customerMap = BankDB.getCustomerMap();
	WalletService walletService = new WalletServiceImpl();
	Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		String option = null;

		Client c = new Client();
		while (true) {
			System.out.println("========Bank Management System========");
			System.out.println("1. Create Account ");
			System.out.println("2. Show Balance ");
			System.out.println("3. Deposit ");
			System.out.println("4. Withdraw ");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");
			System.out.println("Choose an option");
			option = c.scan.nextLine();
			switch (option) {
			case "1":
				c.createAccount();
				break;
			case "2":
				c.showBalance();
				break;
			case "3":
				c.deposit();
				break;
			case "4":
				c.withdraw();
				break;
			case "5":
				c.fundTransfer();
				break;
			case "6":
				c.printTransaction();
				break;
			case "7":
				System.exit(0);
				break;
			default:
				System.err.println("Invalid Option Choose from 1 to 7");
				System.out.println();
				break;

			}
		}
	}

	void createAccount() {
		Customer cus = new Customer();
		/*
		 * System.out.println("Enter customer Account Number: ");
		 * cust.setAccNumber(Integer.parseInt(scan.nextLine()));
		 */
		System.out.println("Enter customer name: ");
		cus.setcustName(scan.nextLine());
		System.out.println("Enter customer mobile number: ");
		cus.setMobile(scan.nextLine());
		System.out.println("Enter customer email: ");
		cus.setEmail(scan.nextLine());
		System.out.println("Enter customer address: ");

		cus.setAddress(scan.nextLine());
		try {
			boolean res = walletService.validateCustomer(cus);
			if (res) {
				int ret = walletService.createAccount(cus);
				System.out.println("Customer with Id " + ret + " created successfully");
				System.out.println("Set your pin: ");
				cus.setPin(Integer.parseInt(scan.nextLine()));
				System.out.println("Your pin is set successfully!! ");
			}
		} catch (WalletException e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}
	}

	void showBalance() {
		System.out.println("Enter Account Number of the Account holder to view: ");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = customerMap.get(num).getPin();
			if (pin == pin1) {

				Customer cust = walletService.showBalance(num);
				System.out.println(cust);
			} else
				System.out.println("Invalid pin");
		} catch (WalletException e) {
			System.err.println("An error occured" + e.getMessage());
		}

	}

	void deposit() {
		System.out.println("Enter account number");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = customerMap.get(num).getPin();
			if (pin == pin1) {

				System.out.println("Enter the Amount to deposit");
				double amount = Double.parseDouble(scan.nextLine());

				boolean res = walletService.deposit(num, amount);
				if (res) {
					System.out.println("Customer with account number " + num + " money deposited successfully");
				} else
					System.out.println("Invalid");
			} else
				System.out.println("Invalid pin ");
		} catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();

		}

	}

	void withdraw() {
		System.out.println("Enter account number");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = customerMap.get(num).getPin();
			if (pin == pin1) {

				System.out.println("Enter amount to withdraw");
				double amount = Double.parseDouble(scan.nextLine());

				boolean res = walletService.withdraw(num, amount);
				if (res) {
					System.out.println("Customer with account number " + num + " money withdrawn successfully");
				} else
					System.out.println("Invalid");
			} else
				System.out.println("Invalid pin ");
		} catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();

		}

	}

	void fundTransfer() {
		System.out.println("Enter account number:");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		System.out.println("Enter destination account number:");
		int num1 = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = customerMap.get(num).getPin();
			if (pin == pin1) {

				System.out.println("Enter amount to transfer");
				double amount = Double.parseDouble(scan.nextLine());

				boolean res = walletService.fundTransfer(num, num1, amount);
				if (res) {
					System.out.println("Customer with account number " + num + " money transferred successfully to account number "+num1);
				} else
					System.out.println("Invalid");
			} else
				System.out.println("Invalid pin ");
		} catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();

		}

	}

	void printTransaction() {
		System.out.println("Enter account number:");
		int num = Integer.parseInt(scan.nextLine());
		System.out.println("Enter pin");
		int pin = Integer.parseInt(scan.nextLine());
		try {
			int pin1 = customerMap.get(num).getPin();
			if (pin == pin1) {
				System.out.println("Transaction statement:");
			String s=walletService.printTransaction(num);
			System.out.println();
			System.out.println(s);
			System.out.println();
			}
			else
				System.out.println("invalid pin");
	
		}
		catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();

		}
	}
}
